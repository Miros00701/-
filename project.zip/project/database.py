import sqlite3 as sql

class Database:
    def __init__(self) -> None:
        self.con = sql.connect("PhoneBook.db")
        self.cur = self.con.cursor()
        self.cur.execute("""
            CREATE TABLE IF NOT EXISTS usr (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    full_name TEXT,
                    phone_number TEXT,
                    email TEXT
            )
        """)
    
    def insert_data(self, full_name, phone_number, email):
        self.cur.execute("""
            INSERT INTO usr (full_name, phone_number, email)
                VALUES (?, ?, ?)
        """, (full_name, phone_number, email))
        self.con.commit()
    
    def update_data(self, id, full_name, phone_number, email):
        self.cur.execute("""
            UPDATE usr
                SET
                    full_name = ?, 
                    phone_number = ?, 
                    email = ?
                WHERE
                    id = ?
        """, (full_name, phone_number, email, id))
        self.con.commit()
    
    def remove_data(self, id):
        self.cur.execute("""
            DELETE FROM usr WHERE id = ?
        """, (id,))
        self.con.commit()