import tkinter as tk
from tkinter import ttk
from PIL import ImageTk
from PIL import Image
import database

class Main(tk.Frame):
    def __init__(self, root):
        super().__init__(root)
        self.db: database.Database = db

    # init widgets
    def init_main(self):
        #ToolBar
        toolbar = tk.Frame(bg="#d7d7d7", bd=1)
        toolbar.pack(side=tk.TOP, fill=tk.X)

        toolbar2 = tk.Frame(bg="#ebebeb", bd=1)
        toolbar2.pack(side=tk.BOTTOM, fill=tk.BOTH, expand=True)

        # Button "Add Contact"
        img = Image.open("./res/add.png")
        self.add_cont_img = ImageTk.PhotoImage(img.resize((int(img.width*.17),int(img.height*.17))))
        btn_cont_add = tk.Button(toolbar, image=self.add_cont_img, bg="#d7d7d7", bd=0, command=self.open_child)
        btn_cont_add.pack(side=tk.LEFT)

        # Button "Update Contact"
        img = Image.open("./res/update.png")
        self.upd_cont_img = ImageTk.PhotoImage(img.resize((int(img.width*.17),int(img.height*.17))))
        btn_cont_upd = tk.Button(toolbar, image=self.upd_cont_img, bg="#d7d7d7", bd=0, command=self.open_upd)
        btn_cont_upd.pack(side=tk.LEFT)

        # Button "Delete Contact"
        img = Image.open("./res/delete.png")
        self.del_cont_img = ImageTk.PhotoImage(img.resize((int(img.width*.17),int(img.height*.17))))
        btn_cont_del = tk.Button(toolbar, image=self.del_cont_img, bg="#d7d7d7", bd=0, command=self.remove)
        btn_cont_del.pack(side=tk.LEFT)
        
        # Button "Search Contact"
        img = Image.open("./res/search.png")
        self.srch_cont_img = ImageTk.PhotoImage(img.resize((int(img.width*.17),int(img.height*.17))))
        btn_cont_srch = tk.Button(toolbar, image=self.srch_cont_img, bg="#d7d7d7", bd=0, command=self.open_search)
        btn_cont_srch.pack(side=tk.LEFT)

        # Button "Search Contact"
        img = Image.open("./res/refresh.png")
        self.updlist_cont_img = ImageTk.PhotoImage(img.resize((int(img.width*.17),int(img.height*.17))))
        btn_cont_updlist = tk.Button(toolbar, image=self.updlist_cont_img, bg="#d7d7d7", bd=0, command=self.view_records)
        btn_cont_updlist.pack(side=tk.LEFT)

        # TreeView "Tree"
        self.tree = ttk.Treeview(toolbar2, columns=('ID', 'full_name', 'phone_number', 'email',), show='headings')
        
        # TreeView config
        self.tree.column('ID', width=45, anchor="center")
        self.tree.column('full_name', width=300, anchor="center")
        self.tree.column('phone_number', width=150, anchor="center")
        self.tree.column('email', width=150, anchor="center")

        #add headings
        self.tree.heading('ID', text='ID')
        self.tree.heading('full_name', text='Full name')
        self.tree.heading('phone_number', text='Phone number')
        self.tree.heading('email', text='email')
        
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.view_records()

        #scrollbar
        scrlbar = tk.Scrollbar(toolbar2, command=self.tree.yview)
        scrlbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.tree.configure(yscrollcommand=scrlbar.set)


    def record(self, full_name, phone, email):
        """records data to database"""

        self.db.insert_data(full_name, phone, email)
        self.view_records()
    
    def update(self, full_name, phone, email):
        id = self.tree.set(self.tree.selection()[0], '#1')
        self.db.update_data(id, full_name, phone, email)
        self.view_records()

    #init "add contact"
    def open_child(self):
        Child().init_child()
    
    #init "update contact"
    def open_upd(self):
        ChildUpdate().init_update()
    
    #init "search"
    def open_search(self):
        Search().init_search()

    def search(self, name):
        for child in self.tree.get_children():
            self.tree.delete(child)
        
        self.db.cur.execute('SELECT * FROM usr WHERE full_name LIKE ?', (name,))

        r = self.db.cur.fetchall()

        for child in r:
            self.tree.insert('', 'end', values=child)

    #remove contact
    def remove(self):
        for id in self.tree.selection():
            self.db.remove_data(self.tree.set(id, '#1'))
        
        self.view_records()
    
    #add data to tree (TreeView)
    def view_records(self):
        """Adds data to TreeView"""

        #clear old data
        for child in self.tree.get_children():
            self.tree.delete(child)
        
        self.db.cur.execute("SELECT * FROM usr")

        #fill new data
        data = self.db.cur.fetchall()
        for dat in data:
            self.tree.insert('', 'end', values=dat)


class Child(tk.Toplevel):

    def __init__(self) -> None:
        super().__init__()
        self.view = app

    #init widgets of child
    def init_child(self):
        self.title("Add contact")
        self.geometry("600x200")
        self.resizable(False, False)

        #grab and focus set
        self.grab_set()
        self.focus_set()

        #labels
        label_name = tk.Label(self, text="Full name")
        label_phone = tk.Label(self, text="Phone number")
        label_email = tk.Label(self, text="Email")

        label_name.place(x=50, y=50)
        label_phone.place(x=50, y=80)
        label_email.place(x=50, y=110)

        #entries
        self.input_name = tk.Entry(self)
        self.input_phone = tk.Entry(self)
        self.input_email = tk.Entry(self)

        self.input_name.place(x=240, y=50)
        self.input_phone.place(x=240, y=80)
        self.input_email.place(x=240, y=110)

        #Button "cancel"
        btn_close = tk.Button(self, text="Cancel", command=self.destroy)
        btn_close.place(x=240, y=160)

        #Button "add"
        self.btn_add = tk.Button(self, text="Add")
        self.btn_add.bind("<Button-1>", lambda ev: 
        (
            self.view.record
            (
                self.input_name.get(),
                self.input_phone.get(),
                self.input_email.get()
            ), 
            self.destroy()
        ))
        self.btn_add.place(x=300, y=160)


class ChildUpdate(Child):
    def __init__(self) -> None:
        super().__init__()
        self.init_child()
        self.get_data()

    #init child_update
    def init_update(self): 
        self.title("Update contact")
        self.btn_add.destroy()

        # Button "update"
        self.btn_upd = tk.Button(self, text="Update")
        self.btn_upd.bind("<Button-1>", lambda ev: 
        (
            self.view.update
            (
                self.input_name.get(),
                self.input_phone.get(),
                self.input_email.get()
            ), 
            self.destroy()
        ))
        self.btn_upd.place(x=300, y=160)
    
    #get data from selected item in TreeView
    def get_data(self):
        id = self.view.tree.set(self.view.tree.selection()[0], "#1")
        self.view.db.cur.execute('SELECT * FROM usr WHERE id = ?', (id,))
        row = self.view.db.cur.fetchone()
        self.input_name.insert(0, row[1])
        self.input_phone.insert(0, row[2])
        self.input_email.insert(0, row[3])

class Search(tk.Toplevel):

    def __init__(self) -> None:
        super().__init__()
        self.view = app

    #init widgets of child
    def init_search(self):
        self.title("Search contact")
        self.geometry("500x150")
        self.resizable(False, False)

        #grab and focus set
        self.grab_set()
        self.focus_set()

        #label
        label_name = tk.Label(self, text="Full name")
        label_name.place(x=50, y=50)

        #entry
        self.input_name = tk.Entry(self)
        self.input_name.place(x=240, y=50)

        #Button "cancel"
        btn_close = tk.Button(self, text="Cancel", command=self.destroy)
        btn_close.pack(side=tk.BOTTOM, anchor='s')

        #Button "search"
        self.btn_search = tk.Button(self, text="Search", )
        self.btn_search.bind("<Button-1>", lambda ev: (self.view.search(self.input_name.get()), self.destroy()), add="+")
        self.btn_search.pack(side=tk.BOTTOM, anchor='s')


if __name__ == "__main__":
    root = tk.Tk()
    root.title("PhoneBook")
    root.geometry("800x465")
    root.resizable(False,False)

    db = database.Database()
    app = Main(root)
    app.init_main()

    root.mainloop()
